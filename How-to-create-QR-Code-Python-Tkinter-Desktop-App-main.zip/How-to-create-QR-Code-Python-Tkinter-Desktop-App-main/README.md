# How-to-create-QR-Code-Python-Tkinter-Desktop-App

ALL PLAYLIST (+150 videos) 👉 https://www.youtube.com/c/TurtleCode/playlists
![12312121212121212](https://user-images.githubusercontent.com/85156399/171329636-bda2f358-a746-4583-83e8-1b415e1194c7.png)

